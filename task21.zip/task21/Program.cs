﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace task21
{
    class Program
    {
        private static int[,] Garden;
        private static int Sadovnik1;
        private static int Sadovnik2;
        static object loker = new object();
        static void Main()
        {
            Console.WriteLine("Введите сторону участка");
            int Side = Convert.ToInt32(Console.ReadLine());
            Sadovnik1 = Side;
            Sadovnik2 = Side;
            Garden = new int[Side, Side];
            Thread SadovnikWork1 = new Thread(Garden1);
            Thread SadovnikWork2 = new Thread(Garden2);
            SadovnikWork1.Start();
            SadovnikWork2.Start();
            Console.ReadKey();
        }
        private static void Garden1()
        {
            lock (loker)
                for (int i = 0; i < Sadovnik2; i++)
                {
                    for (int j = 0; j < Sadovnik1; j++)
                    {
                        if (Garden[i, j] == 0)
                            Garden[i, j] = 1;
                        Console.Write(Garden[i, j] + " ");
                        Console.WriteLine();
                        Thread.Sleep(100);
                    }
                }
        }
        private static void Garden2()
        {
            for (int i = Sadovnik1 - 1; i > 0; i--)
            {
                for (int j = Sadovnik2 - 1; j > 0; j--)
                {
                    if (Garden[j, i] == 0)
                        Garden[j, i] = 2;
                    Console.Write(Garden[i, j] + " ");
                    Thread.Sleep(100);
                }
            }
        }
    }
}
